val = sim('Gorev3');
time = val.tout;
x2 = val.simout1;
x1 = val.simout;
plot(x1.Data, x2.Data); %Simulink datasinin workspace'e çekilmesi ve grafiğe çizimi
hold on
plot(x1.Data(1),x2.Data(1),'*'); %Gelen datanin ilk degiskeni baslangic noktasi olacak
xlabel('x1(t)');%grafiğin x ekseninin adlandırılması
ylabel('x2(t)');%grafiğin y ekseninin adlandırılması
grid
title('x1(t) - x2(t) Grafiği')%grafiğe başlık koyulması
hold off